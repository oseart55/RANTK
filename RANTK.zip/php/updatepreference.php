<?php
@include 'config.php';
if(isset($_GET['name']) && isset($_GET['email'])){
	$user_id = $_GET['name'];
	$email = $_GET['email'];
	
	$user = [
	'name' => $user_id,
	'email' => $email,
	];

	$sql = 'UPDATE user_form
			SET `mode` = NOT `mode`
			WHERE name = :name
			AND email = :email';

	// prepare statement
	$statement = $pdo->prepare($sql);

	// bind params
	$statement->bindParam(':name', $user['name'], PDO::PARAM_STR);
	$statement->bindParam(':email', $user['email'], PDO::PARAM_STR);
	
	if ($statement->execute()) {
		echo 'The User has been updated successfully!';
		$select = " SELECT * FROM user_form WHERE name = '$user_id' && email = '$email' ";
		$result = $pdo->query($select);
		if($result){
			$mode = $result->fetch(PDO::FETCH_ASSOC);
			$_SESSION['mode'] = $mode;
		};
	}
	
	
	
	
	
	
	// $sql = "UPDATE `user_form` SET `mode` = $mode WHERE name = :name AND email = :email";
		
	// $stmt = $pdo->prepare($sql);
	// $stmt->bindParam(':name', $user_id, PDO::PARAM_STR);
	// $stmt->bindParam(':email', $email, PDO::PARAM_STR);
	// $stmt->execute();
		
	// echo "done";
}

	
?>