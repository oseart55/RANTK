<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name'])){
   header('location:login');
}

if(isset($_SESSION['messageGroup'])){
    $_SESSION['messageGroup'] = "";
}


$group = $_POST['grp'];
$_SESSION['messageGroup'] = $group;


?>