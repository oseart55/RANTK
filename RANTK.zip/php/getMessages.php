<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name'])){
   header('location:login');
}
$sql = 'SELECT content
			FROM message
			WHERE user_id = :name';

	// prepare statement
	$statement = $pdo->prepare($sql);

	// bind params
	$statement->bindParam(':name', $_SESSION['name'], PDO::PARAM_STR);
	$result = $statement->fetch(PDO::FETCH_ASSOC);
	echo $result['message'];

?>