<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name'])){
   header('location:login');
}
?>

<!DOCTYPE html>
<html lang='en'>
	<meta http-equiv="refresh" content="0; URL=/assetmap" />
</html>