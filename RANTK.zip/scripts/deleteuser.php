<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');
if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'admin'){
   header('location:../login');
}

if(isset($_GET['name']) && isset($_GET['email'])) {
    $user_id = $_GET['name'];
	$email = $_GET['email'];
	$stmt = $pdo->prepare("DELETE FROM user_form WHERE name= ? AND email = ?");
	$stmt->bindParam(1, $user_id, PDO::PARAM_STR);
	$stmt->bindParam(2, $email, PDO::PARAM_STR);
	$stmt->execute();
	if ($stmt) {
	  echo '<h1 style="color:red; text-align: center;">Record deleted successfully. Redirecting you back in 5 seconds.</h1>';
	} else {
	  echo "Error Deleting record.";
	}
}
?>
<html>
<meta http-equiv="refresh" content="5; URL=/manageusers" />
</html>
