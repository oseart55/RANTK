<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');
if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'admin'){
   header('location:../login');
}

if(isset($_GET['name']) && isset($_GET['email'])) {
    $user_id = $_GET['name'];
	$email = $_GET['email'];
	$stmt = $pdo->prepare("UPDATE user_form SET user_type = 'user' WHERE name= ? AND email = ?");
	$stmt->bindParam(1, $user_id, PDO::PARAM_STR);
	$stmt->bindParam(2, $email, PDO::PARAM_STR);
	$stmt->execute();
	if ($stmt) {
	  echo '<h1 style="color:red; text-align: center;">Record updated successfully. Redirecting you back.</h1>';
	} else {
	  echo "Error Updating Record.";
	}
}
?>
<html>
<meta http-equiv="refresh" content="3; URL=/manageusers" />
</html>