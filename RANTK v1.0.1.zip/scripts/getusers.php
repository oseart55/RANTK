<?php
    require_once(dirname(__FILE__) . '..\..\config\config.php');
    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    $stmt = $pdo->query('SELECT name,email,user_type FROM `user_form` ORDER BY name');
		while ($row = $stmt->fetch()) {
			printf("<tr>
				<td>%s</td>
				<td>%s</td>
				<td>%s</td>
				<td>
					<li><a href='/scripts/deleteuser?name=".$row['name']."&email=".$row['email']."' user-data = ".$row['name']." onclick='return confirm_delete_alert(this)'>Delete User</a></li>
					<li><a href='/scripts/promoteuser?name=".$row['name']."&email=".$row['email']."' user-data = ".$row['name']." onclick='return confirm_promote_alert(this)'>Promote User</a></li>
					<li><a href='/scripts/demoteuser?name=".$row['name']."&email=".$row['email']."' user-data = ".$row['name']." onclick='return confirm_demote_alert(this)'>Demote User</a></li>
				</td>
			</tr>",  $row['name'], $row['email'],$row['user_type']);
			 }
		 ?>