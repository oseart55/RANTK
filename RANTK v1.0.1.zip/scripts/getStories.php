<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if (!isset($_SESSION['name']) || $_SESSION['role'] != 'admin') {
    header('location:../login');
}
$data = $_POST['data'];

$stmt = $pdo->prepare("SELECT * FROM $data");
$stories = array();
$stmt->execute();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $stories[] = $row;
}
echo json_encode($stories);

