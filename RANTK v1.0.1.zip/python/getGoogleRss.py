import json, mysql.connector, requests
from xml.dom.minidom import parseString
from ast import literal_eval


mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="website"
)
mycursor = mydb.cursor()


COCOM_LINKS = [{'TABLE': 'general_news', 'LINK': 'https://news.google.com/rss/search?q=WORLD%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'usafricom_news', 'LINK': 'https://news.google.com/rss/search?q=USAFRICOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'uscentcom_news', 'LINK': 'https://news.google.com/rss/search?q=USCENTCOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'useucom_news', 'LINK': 'https://news.google.com/rss/search?q=USEUCOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'usindopacom_news', 'LINK': 'https://news.google.com/rss/search?q=USINDOPACOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'usnorthcom_news', 'LINK': 'https://news.google.com/rss/search?q=USNORTHCOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'uspacom_news', 'LINK': 'https://news.google.com/rss/search?q=USPACOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
               {'TABLE': 'ussouthcom_news', 'LINK': 'https://news.google.com/rss/search?q=USSOUTHCOM%20conflict&hl=en-US&gl=US&ceid=US:en'}]

for command in COCOM_LINKS:
    print(command['TABLE'])
    
    data = requests.get(command['LINK'])
    document = parseString(data.text)

    articles = []
    guids = []

    for item in document.getElementsByTagName("item"):
        title = item.getElementsByTagName("title")
        title = title[0].firstChild.nodeValue
        
        link = item.getElementsByTagName("link")
        link = link[0].firstChild.nodeValue
        
        pubDate = item.getElementsByTagName("pubDate")
        pubDate = pubDate[0].firstChild.nodeValue
        
        source = item.getElementsByTagName("source")
        source = source[0].firstChild.nodeValue

        guid = item.getElementsByTagName("guid")
        guid = guid[0].firstChild.nodeValue
        
        article = {"pubDate": pubDate, "title": title, "link": link, "source": source, "guid": guid}
        articles.append(article)

    for article in articles:
        pubDate=(article['pubDate'])
        title=(article['title'])
        link=(article['link'])
        source=(article['source'])
        guid=(article['guid'])
        
    cursor = mydb.cursor()
    select_all = f"Select * FROM {command['TABLE']}"
    cursor.execute(select_all)
    records = cursor.fetchall()
    
    for record in records:
        guids.append(record[5])
        
    for article in articles:
        if article['guid'] not in guids:
            date = article['pubDate']
            title = article['title']
            title = title.replace("'","")
            link = article['link']
            source = article['source']
            source = source.replace("'","")
            guid = article['guid']
            sql = f"INSERT INTO {command['TABLE']} (`date`, `title`, `link`, `source`, `guid`) VALUES ('"+pubDate+"','"+title+"','"+link+"','"+source+"','"+guid+"')"
            print(sql)
            mycursor.execute(sql)
            mydb.commit()
            print(f"{guid} Added to Database")
        else:
            print(f"{guid} in Database")
    
    
