##import requests,os, js2py, json, zipfile, shutil
##import xml.dom.minidom
##from urllib.request import urlretrieve
##from pathlib import Path
##
##save_path = r'E:\xampp\htdocs\xml_data'
##urls = ["https://www.state.gov/rss-feed/near-east/feed/"]
##
##for url in urls:
##    data = requests.get(url)
##    with open(url.rsplit('/', 3)[-3]+".xml",'w') as file:
##        file.write(data.text)
##    file.close()
import requests, time
from readStories import readStories
def getStories():
    headers = {
    'authority': 'api.dataminr.com',
    'accept': 'application/json, text/javascript',
    'accept-language': 'en-US,en;q=0.9',
    'authorization': 'DmAuth 41f5822acd0848ed91d5fd7dfba7c248',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://app.dataminr.com',
    'referer': 'https://app.dataminr.com/',
    'sec-ch-ua': '"Google Chrome";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    }

    params = {
        'num': '40',
        'from': 'H4sIAAAAAAAAAFWQ3StDcRyHj8/ZkdaSJEmSJElIS5IkhCRJjiRJpq21Wpvm/AGSl9jSOrHWkiIXa+TIS4mE/b5Gy8UsTRTmRiwXFLWEnFuXz9Xz9EBTKRnMZpOx0WpySKPlIwaHZJEsdpvJOBRwE1rjZwS9nGToTdwx5MXeZ/l0+YZhYOlDEdJepwllmz6GZldols+YjxIq6YGhPSwTCv0/DLV0oAgaz9wp2qZ2NwTt9x6hSF4m5HgmCR2/cYb6UIRQd+4i1LzJisCdnxBK11V595bq7btSsdo9Qai4cBIGdz4Zio9PCSXRd4Z+b5Chx6dmNES/GPIXrxUB8gWhc0wNyrp9muGznxVFSF33zvCZ99uErsg9Q1Nkk5C7+sJQECNCVTLg5HWc/t8Km93WYrRIdofFYNV9rwVFuFbW/Cnc+MKRmBbeD4qpoY+wqE3cHooajtvxXcYfh/8ABBV+rE8BAAA=',
        'listViews': '[{"listId":"3667548","brands":["flash","urgent","alert"]},{"listId":"2057371","brands":["flash","urgent","alert"]},{"listId":"2057399","brands":["flash","urgent","alert"]}]',
        'application': 'client-app',
        'alertversion': '12',
        'displayLanguage': 'en-US',
    }

    response = requests.get('https://api.dataminr.com/alerting/2/alerts/stream', params=params, headers=headers)
    print(response)
    with open('dataminr.json','w', encoding="utf-8") as file:
        file.write(response.text)
    file.close()

while 1==1:
    getStories()
    readStories()
    time.sleep(10)
