import requests,os, js2py, json, zipfile, shutil
import xml.dom.minidom
from urllib.request import urlretrieve
from pathlib import Path

save_path = r'E:\xampp\htdocs\xml_data'


TS_Feeds = ['https://www.nhc.noaa.gov/nhc_at1.xml','https://www.nhc.noaa.gov/nhc_at2.xml','https://www.nhc.noaa.gov/nhc_at3.xml','https://www.nhc.noaa.gov/nhc_at4.xml','https://www.nhc.noaa.gov/nhc_at5.xml',
            'https://www.nhc.noaa.gov/nhc_ep1.xml','https://www.nhc.noaa.gov/nhc_ep2.xml','https://www.nhc.noaa.gov/nhc_ep3.xml','https://www.nhc.noaa.gov/nhc_ep4.xml','https://www.nhc.noaa.gov/nhc_ep5.xml',
            'https://www.nhc.noaa.gov/nhc_cp1.xml','https://www.nhc.noaa.gov/nhc_cp2.xml','https://www.nhc.noaa.gov/nhc_cp3.xml','https://www.nhc.noaa.gov/nhc_cp4.xml','https://www.nhc.noaa.gov/nhc_cp5.xml']
##for storm_feed in TS_Feeds:
##    data = requests.get(storm_feed)
##    completeName = os.path.join(save_path, storm_feed.rsplit('/', 1)[-1])
##    with open(completeName,"w") as file:
##        file.write(data.text)
##    file.close()
        
##content = os.listdir(r'E:\xampp\htdocs\xml_data')
##
####for item in content:
####    xml_doc = xml.dom.minidom.parse(os.path.join(save_path, item))
####    channels = xml_doc.getElementsByTagName('channel')
####    for channel in channels:
####        try:
####            atcf = channel.getElementsByTagName('nhc:atcf')[0].childNodes[0].data
####            print("Storm in: "+str(atcf))
####            local = atcf[:-4]
####            url = f"https://www.nhc.noaa.gov/storm_graphics/{local}/{atcf.lower()}_cone.js"
####            data = requests.get(url)
####            with open(item[:-3]+'js','w')as file:
####                file.write(data.text)
####                file.close()
####        except Exception as e:
####            print(channel.getElementsByTagName('title')[0].childNodes[0].data)
##
##new_content = os.listdir(r'E:\xampp\htdocs\python')
##for content in new_content:
##    if('.js' in content):
##        new_name = content[:-2]
##        x = js2py.run_file(content) # Runs the return _cone.js as javascript
##        y = str(x[0]).replace("'",'"') # relaces ' with " so that we can load it into a JSON object
##        z = json.loads(y) # loading into a JSON object
##        layers = list(z) # Get list that contains the Alerts
##        mostCurrent = z[layers[-1]] #Gets the most current (last) alert
##        for k,v in mostCurrent.items(): # Key, Value pairs in the most current alert
##            if("url" in k): # If that key contains the text url....
##                urlretrieve(v,new_name+str(k)+'.kmz')
##
##for filename in os.listdir(os.path.dirname(os.path.abspath(__file__))):
##    base_file, ext = os.path.splitext(filename)
##    if ext == ".kmz":
##        os.rename(filename, base_file + ".zip")
##
##p = Path(__file__).parent.absolute()
##for f in p.glob('*.zip'):
##    with zipfile.ZipFile(f, 'r') as archive:
##        archive.extractall(path=f'./{f.stem}')
##        print(f'Done {f.stem}')
##
##p = Path(__file__).parent.absolute()
### Removing all .zip files
##
##dir_name = p
##test = os.listdir(dir_name)
##for item in test:
##    if item.endswith(".zip"):
##        os.remove(os.path.join(dir_name, item))

new_content = os.listdir(r'E:\xampp\htdocs\python')
list_of_files = {}
for (dirpath, dirnames, filenames) in os.walk(r'E:\xampp\htdocs\python'):
    for filename in filenames:
        if filename.endswith('.kml'):
            dest = r"E:\xampp\htdocs\kmzs"+'\\'+str(filename)
            shutil.move(dirpath+'\\'+str(filename), dest)
            



#dest = r"E:\xampp\htdocs\kmzs"+'\\'+new_name+str(k)+'.kmz'
#shutil.move(new_name+str(k)+'.kmz', dest)
                
                
