tables = [{'COCOM': 'usafricom', 'LINK': 'https://news.google.com/rss/search?q=USAFRICOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
          {'COCOM': 'uscentcom', 'LINK': 'https://news.google.com/rss/search?q=USCENTCOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
          {'COCOM': 'useucom', 'LINK': 'https://news.google.com/rss/search?q=USEUCOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
          {'COCOM': 'usindopacom', 'LINK': 'https://news.google.com/rss/search?q=USINDOPACOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
          {'COCOM': 'usnorthcom', 'LINK': 'https://news.google.com/rss/search?q=USNORTHCOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
          {'COCOM': 'uspacom', 'LINK': 'https://news.google.com/rss/search?q=USPACOM%20conflict&hl=en-US&gl=US&ceid=US:en'},
          {'COCOM': 'ussouthcom', 'LINK': 'https://news.google.com/rss/search?q=USSOUTHCOM%20conflict&hl=en-US&gl=US&ceid=US:en'}]

for command in tables:
    print(command['COCOM'])
    print(command['LINK'])
