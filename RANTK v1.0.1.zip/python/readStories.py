import json, mysql.connector 


mydb = mysql.connector.connect(
  host="https://www.rantk.com",
  user="rantjkdh_matthew",
  password="Gi7Ss13456!#",
  database="website"
)
print(mydb)
##mycursor = mydb.cursor()


##def cleanDB():
##    sql = "DELETE S1 FROM news AS S1 INNER JOIN news AS S2 WHERE S1.id < S2.id AND S1.guid = S2.guid;"
##    mycursor.execute(sql)
##    mydb.commit()
##    print(str(mycursor.rowcount)+" records deleted.")
##
##def readStories():
##    rowcount = 0 
##    with open('dataminr.json','r',encoding="utf-8") as file:
##        data = json.load(file)
##    file.close()
##
##    for item in data['data']['alerts']:
##        for k, v in item.items():
##            if k == 'date':
##                date = v    
##            if k == 'location':
##                coordinates = v['coordinates']
##                coordinates = (str(coordinates[0])+','+str(coordinates[1]))
##            if k == 'headline':
##                headline = v
##            if k == 'headlineData':
##                source = v['via']
##            if k == 'odsStatus':
##                source = v["extraData"]['displaySourceName']
##            if k == 'metadata':
##                guid = v['eventLocations'][0]['associatedJurisdictions'][0]['guid']
##
##        sql = "INSERT INTO news (date, location, headline, source, guid) VALUES (%s, %s, %s, %s, %s)"
##        val = (date, coordinates, headline, source, guid)
##        mycursor.execute(sql, val)
##        mydb.commit()
##        rowcount = rowcount + mycursor.rowcount
##    print(str(rowcount)+" records inserted.")
##    cleanDB()
