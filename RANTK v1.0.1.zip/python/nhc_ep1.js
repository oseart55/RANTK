var text1 = "Interactive Forecast Graphics and Coastal Watches/Warnings"
var current = "004"
 
var layers = {
"004": {
"initialtime": "4:00 pm CDT Sun Oct 08, 2023",
"urlBT":"http://www.nhc.noaa.gov/gis/best_track/ep162023_best_track.kmz",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_004adv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_004adv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_004adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_004adv_most_likely_toa_34.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_004adv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_004adv.kmz",
"name": "Advisory #004",
"storm": "Tropical Depression Sixteen-E"
},
"003A": {
"initialtime": "1:00 pm CDT Sun Oct 08, 2023",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003Aadv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003Aadv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_most_likely_toa_34.kmz",
"url34wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100812_wsp34knt120hr_5km.kmz",
"url50wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100812_wsp50knt120hr_5km.kmz",
"url64wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100812_wsp64knt120hr_5km.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003Aadv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_003Aadv.kmz",
"name": "Advisory #003A",
"storm": "Potential Tropical Cyclone Sixteen-E"
},
"003": {
"initialtime": "10:00 am CDT Sun Oct 08, 2023",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_most_likely_toa_34.kmz",
"url34wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100812_wsp34knt120hr_5km.kmz",
"url50wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100812_wsp50knt120hr_5km.kmz",
"url64wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100812_wsp64knt120hr_5km.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_003adv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_003adv.kmz",
"name": "Advisory #003",
"storm": "Potential Tropical Cyclone Sixteen-E"
},
"002A": {
"initialtime": "7:00 am CDT Sun Oct 08, 2023",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002Aadv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002Aadv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_most_likely_toa_34.kmz",
"url34wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100806_wsp34knt120hr_5km.kmz",
"url50wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100806_wsp50knt120hr_5km.kmz",
"url64wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100806_wsp64knt120hr_5km.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002Aadv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_002Aadv.kmz",
"name": "Advisory #002A",
"storm": "Potential Tropical Cyclone Sixteen-E"
},
"002": {
"initialtime": "4:00 am CDT Sun Oct 08, 2023",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_most_likely_toa_34.kmz",
"url34wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100806_wsp34knt120hr_5km.kmz",
"url50wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100806_wsp50knt120hr_5km.kmz",
"url64wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100806_wsp64knt120hr_5km.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_002adv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_002adv.kmz",
"name": "Advisory #002",
"storm": "Potential Tropical Cyclone Sixteen-E"
},
"001A": {
"initialtime": "1:00 am CDT Sun Oct 08, 2023",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001Aadv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001Aadv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_most_likely_toa_34.kmz",
"url34wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100800_wsp34knt120hr_5km.kmz",
"url50wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100800_wsp50knt120hr_5km.kmz",
"url64wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100800_wsp64knt120hr_5km.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001Aadv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_001Aadv.kmz",
"name": "Advisory #001A",
"storm": "Potential Tropical Cyclone Sixteen-E"
},
"001": {
"initialtime": "10:00 pm CDT Sat Oct 07, 2023",
"urlTrack":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_TRACK.kmz",
"urlCone":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_CONE.kmz",
"urlertoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_earliest_reasonable_toa_34.kmz",
"urlmltoa":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_most_likely_toa_34.kmz",
"url34wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100800_wsp34knt120hr_5km.kmz",
"url50wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100800_wsp50knt120hr_5km.kmz",
"url64wsp":"http://www.nhc.noaa.gov/gis/forecast/archive/2023100800_wsp64knt120hr_5km.kmz",
"urlWW":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_001adv_WW.kmz",
"urlRadii":"http://www.nhc.noaa.gov/storm_graphics/api/EP162023_initialradii_001adv.kmz",
"name": "Advisory #001",
"storm": "Potential Tropical Cyclone Sixteen-E"
}
}
