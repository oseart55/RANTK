<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'admin'){
   header('location:login');
}
$stmt = $pdo->query('UPDATE mode SET `maintance_mode` = NOT `maintance_mode`');
?>
<html>
<meta http-equiv="refresh" content="0; URL=/assetmap" />
</html>