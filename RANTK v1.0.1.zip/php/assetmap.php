<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if (!isset($_SESSION['name'])) {
	header('location:login');
}

?>
<!doctype html>
<html lang="en">

<head>
	<title>Map</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- JQUERY -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
	<!-- LEAFLET -->
	<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
	<script src="https://unpkg.com/leaflet-kmz@latest/dist/leaflet-kmz.js"></script>
	<!-- FONTS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
	<!-- GEOCODER -->
	<link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
	<script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
	<!-- OMNIVORE -->
	<script src='//api.tiles.mapbox.com/mapbox.js/plugins/leaflet-omnivore/v0.3.1/leaflet-omnivore.min.js'></script>
	<!-- leaflet-panel -->
	<script src="../node_modules/leaflet-panel-layers/src/leaflet-panel-layers.js"></script>
	<link rel="stylesheet" href="../node_modules/leaflet-panel-layers/src/leaflet-panel-layers.css" />
	<!-- Draw Control -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/0.4.2/leaflet.draw.css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/0.4.2/leaflet.draw.js"></script>
	<!-- jquery-rss -->
	<!-- leaflet-panel -->
	<script src="../node_modules/jFeed/src/jfeed.js"></script>

	<!-- JQUERY MODAL -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
	<!-- Chat Modal -->
	<link rel="stylesheet" href="css/chat-modal.css">

	<link rel="stylesheet" href="css/testpage.css">
	<meta name="robots" content="noindex, follow">
</head>

<body>
	<div class="wrapper d-flex align-items-stretch">
		<nav id="sidebar" class="active">
			<h1><a href="index.html" class="logo" style="font-size:15px;">RANTK<p>v1</p></a></h1>
			<ul class="list-unstyled components mb-5">
				<li class="active">
					<a href="index.html"><span class="fa fa-home"></span> Home</a>
				</li>
				<li>
					<a href="assetmap"><span class="fa fa-map"></span> Map</a>
				</li>
				<li>
					<a href="#" id="chat-button" class="active"><i class='bx bx-conversation icon' style="font-size: 30px"><span style="font-size: 15px">Chat</span></i></a>
				</li>
				<li>
					<a href="#" id="news-button" class="active"><i class='bx bx-news icon' style="font-size: 30px"><span style="font-size: 15px">News</span></i></a>
				</li>
				<?php
				if ($_SESSION['role'] == "admin") {
					echo "<li class='active'><a href='admin'><span class='fa fa-cogs'></span> Admin Page</a></li>";
					echo "<li class='active'><a href='maintancemode'><span class='fa fa-code'></span> Change Mode</a></li>";
					echo "<li class='active'><a href='manageusers'><span class='fa fa-users'></span> Manage Users</a></li>";
					$stmt = $pdo->query('SELECT maintance_mode FROM `mode`');
					$result = $stmt->fetch(PDO::FETCH_ASSOC);
					if ($result) {
						if ($result['maintance_mode'] == 1) {
							echo " <span class='fa fa-exclamation' style='color:red; font-size:40px;'><li class='active' style='color:white'></span> Site in Maintance Mode</li>";
						}
					}
				};
				?>
				<li class="active" style="position:fixed; left:15px; bottom:0px;">
					<a href="logout"><span style="font-size: 15px">Logout</span><i class='bx bx-log-out icon' style="font-size: 25px"></i></a>
				</li>
			</ul>
		</nav>

		<div id="content" class="p-4 p-md-5">
			<div class="content">
				<div id="map" style="height: 100vh; width: 100%; z-index:1;">
					<script>
						var TSIcon = L.icon({
							iconUrl: 'stormicons/TS.png'
						});
						var map = L.map('map').setView([37, -1], 3);
						var osmLayer = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
							maxZoom: 19,
							attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
						}).addTo(map);
						var OpenTopoMap = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
							maxZoom: 17,
							attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
						});
						// FeatureGroup is to store editable layers
						var drawnItems = new L.FeatureGroup();
						map.addLayer(drawnItems);
						map.addControl(new L.Control.Draw({
							edit: {
								featureGroup: drawnItems,
								poly: {
									allowIntersection: false
								}
							},
							draw: {
								polygon: {
									allowIntersection: false,
									showArea: true
								}
							}
						}));

						map.on(L.Draw.Event.CREATED, function(event) {
							var layer = event.layer;

							drawnItems.addLayer(layer);
						});
						//Add scale bar to map
						L.control.scale().addTo(map);
						//Enable geocoder
						L.Control.geocoder().addTo(map);

						//add kmz layer
						let kmz = L.kmzLayer();
						let Tstorms = L.layerGroup([kmz]);

						// Add News Layer
						let Twitter = L.layerGroup();
						let Scanner = L.layerGroup();
						let Other = L.layerGroup();

						<?php
						$dir    = '../kmzs';
						$scanned_directory = array_diff(scandir($dir), array('..', '.'));
						foreach ($scanned_directory as $file) {
							// printf("kmz.load('/kmzs/$file');");
							printf("L.kmzLayer('/kmzs/$file').addTo(kmz);");
						}
						?>
						//var control = L.control.layers(null, null, { collapsed: true }).addTo(map);
						//Current mouse lat/lon position
						let Position = L.Control.extend({
							_container: null,
							options: {
								position: 'bottomleft'
							},

							onAdd: function(map) {
								var latlng = L.DomUtil.create('div', 'mouseposition');
								latlng.style.background = "white";
								latlng.style.color = "black";
								latlng.style.borderWidth = "medium"
								latlng.style.right = '4px'
								this._latlng = latlng;
								return latlng;
							},

							updateHTML: function(lat, lng) {
								var latlng = lat + " " + lng;
								this._latlng.innerHTML = "Lat: " + lat + '\n' + "Lon:" + lng;
							}
						});
						this.position = new Position();
						this.map.addControl(this.position);
						// current mouse lat/lon position event listener
						this.map.addEventListener('mousemove', (event) => {
							let lat = Math.round(event.latlng.lat * 100000) / 100000;
							let lng = Math.round(event.latlng.lng * 100000) / 100000;
							this.position.updateHTML(lat, lng);
						});
						let popup = L.popup({
							closeButton: false,
							autoClose: true
						});
						//insert php tag here
						// 	$stmt = $pdo->query("SELECT * FROM `news`;");
						// 	$stmt->execute();
						// 	echo "";
						// 	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
						// 		$latlon = $row['location'];
						// 		$data = $row['headline'];
						// 		$source = $row['source'];
						// 		$date = $row['date'];
						// 		echo ("marker = new L.Marker([$latlon]); marker.bindPopup(popup.setLatLng([$latlon]).setContent(`<h1 style='font-weight: bold; font-size:15px;'>Source: $source</h1><p>$data</p><p>$date</p><button onclick='updateButton($(this))'>Update</button>`)); 
						// if('$source' == 'Twitter'){
						// 	marker.addTo(Twitter)
						// }
						// else if ('$source' == 'Scanner') {
						// 	marker.addTo(Scanner)
						// }
						// else{
						// 	marker.addTo(Other)
						// };");
						// 	}
						//insert php tag here
						var baseLayers = [{
								name: "OpenStreetMap",
								layer: osmLayer
							},
							{
								name: "OpenTopoMap",
								layer: OpenTopoMap
							}
						];

						var overLayers = [{
								group: "Tropical Storms",
								layers: [{
									active: false,
									name: "Tropical Storms",
									icon: "<i class='bx bx-wind'></i>",
									layer: Tstorms
								}, ],
								collapsed: true
							},
							{
								group: "News",
								layers: [{
										active: false,
										name: "Twitter",
										icon: "<i class='bx bxl-twitter'></i>",
										layer: Twitter
									},
									{
										active: false,
										name: "Scanner",
										icon: "<i class='bx bx-radio'></i>",
										layer: Scanner
									},
									{
										active: false,
										name: "Other",
										icon: "<i class='bx bx-dots-horizontal-rounded'></i>",
										layer: Other
									},
								],
								collapsed: true,
								icon: "<i class='bx bx-news' ></i>"
							},
						];
						var panelLayers = new L.Control.PanelLayers(baseLayers, overLayers, {
							compact: false,
							collapsed: true,
							collapsibleGroups: false
						});
						map.addControl(panelLayers);

						function updateButton(marker) {
							console.log(marker)
						}
					</script>
				</div>

				<!-- The Modal -->
				<div class="window" id="window">
					<div class="window-bar" id="window-bar">
						<div style="text-align:left">Chat</div>
						<span class="window-close">
							<svg viewport="0 0 12 12" version="1.1" width="25" height="45" xmlns="http://www.w3.org/2000/svg">
								<line x1="1" y1="11" x2="11" y2="1" stroke="black" strokeWidth="2" />
								<line x1="1" y1="1" x2="11" y2="11" stroke="black" strokeWidth="2" />
							</svg>
						</span>
					</div>
				<iframe src="http://localhost:3000" class="row-container"></iframe>
					
				</div>

				<div class="window" id="news-window">
					<div class="window-bar" id="window-bar">
						<div style="text-align:left">Current News</div>
						<span class="window-close">
							<svg viewport="0 0 12 12" version="1.1" width="25" height="45" xmlns="http://www.w3.org/2000/svg">
								<line x1="1" y1="11" x2="11" y2="1" stroke="black" strokeWidth="2" />
								<line x1="1" y1="1" x2="11" y2="11" stroke="black" strokeWidth="2" />
							</svg>
						</span>
					</div>
					<div class="window-body">
						<div class="window-body-groups" style="border-right: 2px solid #000000;">
							<h1 style="text-align:center; font-size: 20px; border-bottom: 2px solid #000000;margin-bottom:0;" class="news-group">General News</h1>
							<div class="window-groups" style="text-align:left; overflow:auto" id="chat-groups">
								<button class="grps-btn" data="general_news">General News</button>
								<button class="grps-btn" data="usnorthcom_news">USNORTHCOM</button>
								<button class="grps-btn" data="ussouthcom_news">USSOUTHCOM</button>
								<button class="grps-btn" data="uspacom_news">USPACOM</button>
								<button class="grps-btn" data="useucom_news">USEUCOM</button>
								<button class="grps-btn" data="usindopacom_news">USINDOPACOM</button>
								<button class="grps-btn" data="uscentcom_news">USCENTCOM</button>
								<button class="grps-btn" data="usafricom_news">USAFARICOM</button>
							</div>
							<div class="news-history" id="news-hist" style="overflow: auto; height: 370px;">

							</div>
						</div>
					</div>
				</div>

				<script>
					let btnSubmits = document.getElementsByClassName('grps-btn');
					for (btn of btnSubmits) {
						btn.addEventListener('click', function(e) {
							var grp = e.srcElement.attributes[1].nodeValue
							$(document.getElementsByClassName('news-group')).text(e.srcElement.innerHTML);
							loadStories(grp);
						});
					}

					function updateGroup(grp) {
						document.getElementById('current-Group').innerText = grp;
					}

					function setGroup(data) {
						console.log(data.innerHTML)
					}

					


					// Get the modal
					var modal = document.getElementById("window");
					var newsModal = document.getElementById("news-window");

					// Get the button that opens the modal
					var btn = document.getElementById("chat-button");
					var newsBtn = document.getElementById("news-button");

					// Get the <span> element that closes the modal
					var span = document.getElementsByClassName("window-close")[0];
					var newsSpan = document.getElementsByClassName("window-close")[1];

					// When the user clicks on the button, open the modal
					btn.onclick = function() {
						modal.style.display = "block";
						modal.hidden = false;
						
					}
					newsBtn.onclick = function() {
						newsModal.style.display = "block";
						newsModal.hidden = false;
						$("news-history").empty();
						loadStories("general_news");
					}
					// When the user clicks on <span> (x), close the modal
					span.onclick = function() {
						modal.style.display = "none";
						modal.hidden = true;

					}
					newsSpan.onclick = function() {
						newsModal.style.display = "none";
						newsModal.hidden = true;

					}

					function loadStories(grp) {
						$(".news-history").empty();
						$.ajax({
							type: "POST",
							url: "../scripts/getStories.php",
							data: {
								'data': grp
							} //pass data through this variable
						}).done(function(msg) {
							if (msg.length > 2) {
								for (story of JSON.parse(msg)) {
									let article = document.createElement('a')
									article.setAttribute('href', story['link'])
									article.setAttribute('target', '_blank')
									article.setAttribute('class', 'a-tag-article')
									let list_item = document.createElement("li");
									list_item.setAttribute('class', 'article')
									let header1 = document.createElement("header");
									let header2 = document.createElement("header");
									let date = document.createTextNode(story['date']);
									let title = document.createTextNode(story['title']);
									header1.appendChild(date);
									header2.appendChild(title);
									list_item.appendChild(header1)
									list_item.appendChild(header2)
									list_item.setAttribute('style', 'list-style-type: none')
									article.appendChild(list_item)
									document.getElementById("news-hist").appendChild(article);
								}
							} else {
								let notice = document.createElement('h1')
								text = document.createTextNode("Error Loading Stories.");
								notice.appendChild(text)
								notice.setAttribute('style', 'font-size:25px;')
								document.getElementById("news-hist").appendChild(notice);
							}
						});

					}

					dragElement(modal);
					dragElement(newsModal);

					function dragElement(elmnt) {
						var pos1 = 0,
							pos2 = 0,
							pos3 = 0,
							pos4 = 0;
						if (document.getElementById(elmnt.id + "header")) {
							/* if present, the header is where you move the DIV from:*/
							document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
						} else {
							/* otherwise, move the DIV from anywhere inside the DIV:*/
							elmnt.onmousedown = dragMouseDown;
						}

						function dragMouseDown(e) {
							e = e || window.event;
							e.preventDefault();
							// get the mouse cursor position at startup:
							pos3 = e.clientX;
							pos4 = e.clientY;
							document.onmouseup = closeDragElement;
							// call a function whenever the cursor moves:
							document.onmousemove = function() {
								elementDrag();
							};

						}

						function elementDrag(e) {

							e = e || window.event;
							e.preventDefault();
							// calculate the new cursor position:
							pos1 = pos3 - e.clientX;
							pos2 = pos4 - e.clientY;
							pos3 = e.clientX;
							pos4 = e.clientY;
							// set the element's new position:
							elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
							elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
						}

						function closeDragElement() {
							/* stop moving when mouse button is released:*/
							document.onmouseup = null;
							document.onmousemove = null;
						}
					}
				</script>
			</div>
			<div class="footer" style="position:fixed; left:0px; bottom:0px; height:30px; width:100%;">
				<p>
					Copyright &copy;<script>
						document.write(new Date().getFullYear());
					</script> All rights reserved | This template is made with <span class='fa fa-heart' aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib.com</a>
				</p>
			</div>
</body>

</html>