<?php

require_once(dirname(__FILE__) . '..\..\config\config.php');

if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(!isset($_SESSION['name'])){
   header('location:login');
}

?>
<!doctype html>
<html lang="en">
<head>
<title>Home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="css/testpage.css">
<meta name="robots" content="noindex, follow">
<body>
<div class="wrapper d-flex align-items-stretch">
<nav id="sidebar" class="active">
<h1><a href="index.html" class="logo" style="font-size:15px;">RANTK<p>v1</p></a></h1>
<ul class="list-unstyled components mb-5">
<li class="active">
<a href="index.html"><span class="fa fa-home"></span> Home</a>
</li>
<li>
<a href="assetmap"><span class="fa fa-map"></span> Map</a>
</li>
<?php
	if($_SESSION['role'] == "admin"){
		echo "<li class='active'><a href='admin'><span class='fa fa-cogs'></span> Admin Page</a></li>";
		echo "<li class='active'><a href='maintancemode'><span class='fa fa-code'></span> Change Mode</a></li>";
		echo "<li class='active'><a href='manageusers'><span class='fa fa-users'></span> Manage Users</a></li>";
	};
?>
<li class="active" style="position:fixed; left:15px; bottom:0px;">

<a href="logout"><span style = "font-size: 15px">Logout</span><i class='bx bx-log-out icon' style = "font-size: 25px"></i></a>
</li>
</ul>
</nav>
<link rel="stylesheet" href="css/testpage.css">
<div id="content" class="p-4 p-md-5">
<div class="content">
<div>
	<style>
		table {
			font-family: Arial, Helvetica, sans-serif; 
			border-collapse: collapse; width: 100%;
			
		}
		tr:nth-child(even){
			background-color: #f2f2f2;
		}
		tr:hover {
			background-color: #ddd
		}
		th {
			padding-top: 12px;
			padding-bottom: 12px;
			text-align: left;
			background-color: #04AA6D;
			color: white;
			text-align: center;
		}
		

	</style>
		 <table>
		  <tr>
			<th>Name</th>
			<th>Email</th>
			<th>User Type</th>
			<th>Action</th>
			
		  </tr>
		   <?php require_once(dirname(__FILE__) . '..\..\scripts\getusers.php');?>
		 <script type="text/javascript">
			function confirm_delete_alert(node) {
				id = node.getAttribute("user-data");
				//debugger;
				return confirm("About to delete the User: "+id+" are you sure?");
			}
			function confirm_promote_alert(node) {
				id = node.getAttribute("user-data");
				//debugger;
				return confirm("About to promote the User: "+id+" are you sure?");
			}
			function confirm_demote_alert(node) {
				id = node.getAttribute("user-data");
				//debugger;
				return confirm("About to demote the User: "+id+" are you sure?");
			}
			</script>
		</table>
  </div>
</div>
<div class="footer" style="position:fixed; left:0px; bottom:0px; height:30px; width:100%;">
	<p>
		Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <span class='fa fa-heart' aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib.com</a>
	</p>
</div>
</body>
</html>