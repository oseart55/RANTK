<?php
//error_reporting(E_ERROR | E_PARSE);
require_once(dirname(__FILE__) . '..\..\config\config.php');
if(session_status() !== PHP_SESSION_ACTIVE) session_start();

if(isset($_SESSION['name']) && $_SESSION['role'] == 'user'){
   header('location:user');
}
elseif(isset($_SESSION['name']) && $_SESSION['role'] == 'admin'){
	header('location:admin');
}

if(isset($_POST['submit'])){

   $email = $_POST['email'];
   $pass = md5($_POST['password']);

   $select = " SELECT * FROM user_form WHERE email = '$email' && password = '$pass' ";
   $result = $pdo->query($select);
   if($result){
	$counter=0;
		while($row = $result->fetch()){
			$counter++;
			if($row['user_type'] == 'admin'){
				$_SESSION['name'] = $row['name_id'];
				$_SESSION['email'] = $row['email'];
				$_SESSION['role'] = $row['user_type'];
				$_SESSION['mode'] = $row['mode'];
				header('location:admin');
				}
			elseif($row['user_type'] == 'user'){
				$_SESSION['name_id'] = $row['name_id'];
				$_SESSION['email'] = $row['email'];
				$_SESSION['role'] = $row['user_type'];
				$_SESSION['mode'] = $row['mode'];
				header('location:user');
			}
			else{
				$error[] = 'incorrect email or password!';
			}
		}

    };
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<div class="header" style="color:red; text-align: center;">
	<span>
		<?php 
			$stmt = $pdo->prepare('SELECT maintance_mode FROM `mode`');
			$stmt->execute();
			$result = $stmt->fetch();
			if($result){
				if ($result['maintance_mode'] == 1){
					echo "<h1>Site currently under maintance, you might experience some interuptions.</h1>";
				}
			}
			
		?>
	</span>
</div>

<div class="form-container">

   <form action="" method="post">
      <h3>Login</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
      <input type="submit" name="submit" value="login now" class="form-btn">
      <p>Don't have an account? <a href="register">Register now</a></p>
   </form>

</div>

</body>
</html>